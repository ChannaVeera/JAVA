package com.BridgeIt.Oops.CliniqueManagementProgramme;

public interface IClinique{
	 String name="";
	 int id=0;
	 String specialization="";
	 String avl="";
	 String mobNumber="";
	 int age=0;
	String doctorFile = "/home/admin123/Documents/workourt/Java-Programs/src/com/BridgeIt/Oops/CliniqueManagementProgramme/Docter.json";
	String patientFile = "/home/admin123/Documents/workourt/Java-Programs/src/com/BridgeIt/Oops/CliniqueManagementProgramme/Patient.json";
	String appointmentFile = "/home/admin123/Documents/workourt/Java-Programs/src/com/BridgeIt/Oops/CliniqueManagementProgramme/Appointment.json";


}
